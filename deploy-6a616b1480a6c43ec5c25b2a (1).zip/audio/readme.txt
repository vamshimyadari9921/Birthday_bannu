Drop Darshu's background music track here as: birthday-tune.mp3

The page references /audio/birthday-tune.mp3 (see src/components/BackgroundMusic.tsx).
Until a real file is added, the mute/unmute button auto-hides and the page runs silently —
no errors, just no music.

Tips:
- Keep the file under ~6-8MB for fast mobile loads (a 128-192kbps MP3 is plenty).
- Trim/loop-friendly clips (fade in/out at the edges) sound best since the track loops.
